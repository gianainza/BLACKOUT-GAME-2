#!/usr/bin/env python3
"""Generates Textures/rg03_badge.png: the round chest badge of the orange RG-03 droid.
Own work (CC0). Run from the repo root:  python tools/make_droid_badge.py   (needs pillow numpy)
The disc is a cylinder cap that faces the droid's +x, whose UVs run u = local x (down the chest) and
v = local z (toward the droid's right).  We draw the badge as a viewer sees it, then transpose it to match."""
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont

OUT = os.path.join("Skybox Activity", "ActivityJ_Skybox", "SkyboxLab", "Textures", "rg03_badge.png")
S = 512
im = Image.new("RGB", (S, S), (222, 224, 228))
d = ImageDraw.Draw(im)
c = S // 2
def ring(r, fill):
    d.ellipse([c - r, c - r, c + r, c + r], fill=fill)

ring(255, (150, 152, 158))      # outer bezel
ring(238, (232, 234, 238))      # bright silver face
ring(205, (90, 92, 98))         # engraved groove
ring(198, (214, 216, 221))
for r, col in ((178, (225, 70, 55)), (160, (214, 216, 221)), (140, (80, 82, 88)), (134, (214, 216, 221))):
    ring(r, col)                # red ring, silver, dark groove, silver
for a in range(0, 360, 30):     # tick marks around the red ring
    v = np.array([np.cos(np.radians(a)), np.sin(np.radians(a))])
    d.line([tuple(c + v * 182), tuple(c + v * 196)], fill=(90, 92, 98), width=5)
ring(100, (232, 234, 238))
ring(74, (225, 70, 55))         # record-style red centre
ring(52, (245, 245, 248))
ring(30, (225, 70, 55))
ring(10, (250, 250, 250))
try:
    font = ImageFont.truetype("DejaVuSans-Bold.ttf", 46)
except Exception:
    font = ImageFont.load_default()
txt = "RG-03"
w = d.textlength(txt, font=font)
d.rounded_rectangle([c - w / 2 - 16, 398, c + w / 2 + 16, 456], 12, fill=(40, 42, 48))
d.text((c - w / 2, 402), txt, fill=(235, 235, 240), font=font)

D = np.array(im)                       # D[Y][X]: what the player sees
tex = D.transpose(1, 0, 2)[::-1]       # tex[r][c] = D[c][S-1-r]
Image.fromarray(np.ascontiguousarray(tex), "RGB").save(OUT)
im.save("/home/claude/badge_preview.png")
print("wrote", OUT)
